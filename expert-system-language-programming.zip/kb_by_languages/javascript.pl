language(javascript) :-
  why(make_money),
  which_platform(web),
  web(front_end).

language(javascript) :-
  why(make_money),
  which_platform(web),
  web(back_end),
  want_to_work_for(startup),
  try_something_new(yes).

