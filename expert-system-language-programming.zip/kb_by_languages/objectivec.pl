language(objectivec) :-
  why(make_money),
  which_platform(mobile),
  which_mobile_os(ios).

language(objectivec) :-
  why(make_money),
  which_platform(apple).
