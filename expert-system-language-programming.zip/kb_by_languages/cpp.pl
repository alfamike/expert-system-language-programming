language(cpp) :-
  why(make_money),
  which_platform(gaming).

language(cpp) :-
  why(just_for_fun),
  prefer_to_learn(hardest_way).

language(cpp) :-
  why(im_interested),
  prefer_to_learn(hardest_way).

language(cpp) :-
  why(improve_myself),
  prefer_to_learn(hardest_way).
