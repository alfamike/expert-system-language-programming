language(c) :-
  why(just_for_fun),
  prefer_to_learn(harder_way),
  car(manual).

language(c) :-
  why(im_interested),
  prefer_to_learn(harder_way),
  car(manual).

language(c) :-
  why(improve_myself),
  prefer_to_learn(harder_way),
  car(manual).

