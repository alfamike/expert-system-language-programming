% Questions for the knowledge base

question_courses(level) :-
  write('What level do you have? (Beginner,Intermediate,Advanced)'), nl.

question_courses(rating) :-
  write('Minimum course rating (Low, Medium, High)'), nl.