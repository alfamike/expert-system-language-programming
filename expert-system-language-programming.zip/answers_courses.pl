% Answers for the knowledge base

answer_courses(beginner) :-
  write('Beginner').

answer_courses(intermediate) :-
  write('Intermediate').

answer_courses(advanced) :-
  write('Advanced').

answer_courses(low) :-
  write('Low').

answer_courses(medium) :-
  write('Medium').

answer_courses(high) :-
  write('High').
  